package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    Button btnJoke, btnGoToGame, btnRepeat, btnClickMe;
    TextView textView;
    public int score = 0;
    public void startNewActivity(View v) {
        Intent integer = new Intent(this, SecondActivity.class);
        startActivity(integer);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        btnClickMe = findViewById(R.id.btnClickMe);
        btnJoke = findViewById(R.id.btnJoke);
        btnRepeat = findViewById(R.id.btnRepeat);

        textView = findViewById(R.id.textView);

        View.OnClickListener clickToPlus = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score++;
                String str;
                if (score % 10 >= 2 && score % 10 <=4) str = "Кнопка нажата " + score + " раза";
                else str = "Кнопка нажата " + score + " раз";
                if (score == 12 || score == 13 || score == 14) str = "Кнопка нажата " + score + " раз";

                textView.setText(str.toCharArray(),0, str.length());
            }
        };
        View.OnClickListener clickToMinus = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                score--;
                String str;
                if (score % 10 >= 2 && score % 10 <=4) str = "Кнопка нажата " + score + " раза";
                else str = "Кнопка нажата " + score + " раз";
                textView.setText(str.toCharArray(),0, str.length());
            }
        };
        View.OnClickListener clickToRepeat = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int score = 0;
                String str;
                str = "Счетчик обнулен";
                textView.setText(str.toCharArray(),0, str.length());
            }
        };
        btnClickMe.setOnClickListener(clickToPlus);
        btnJoke.setOnClickListener(clickToMinus);
        btnRepeat.setOnClickListener(clickToRepeat);
    }
}
