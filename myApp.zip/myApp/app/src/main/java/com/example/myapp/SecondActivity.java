package com.example.myapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Random;

public class SecondActivity extends AppCompatActivity {
    public void startNewActivity(View v) {
        Intent integer = new Intent(this, MainActivity.class);
        startActivity(integer);
    }

    Button setAnswer;
    ImageButton checkAnswer;
    EditText inputAnswer;
    TextView hint, result;
    public Random random = new Random();
    public String res;
    public int number;
    public int Hint1, Hint2;
    public String strHint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_second);

        setAnswer = findViewById(R.id.setAnswer);
        checkAnswer = findViewById(R.id.checkAnswer);
        inputAnswer = findViewById(R.id.inputAnswer);
        hint = findViewById(R.id.hint);
        result = findViewById(R.id.result);

        View.OnClickListener answerSet = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                number = random.nextInt(100);

                Hint1 = random.nextInt(20);
                Hint2 = random.nextInt(25);

                strHint = "Загаданное число находится в диапазоне от " + (number - Hint2) + " до " + (number + Hint1);

                hint.setText(strHint);
            }
        };
        View.OnClickListener answerInput = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float answer = Float.parseFloat(inputAnswer.getText().toString());

                if (answer == number) res = "Вы победили!";
                else if (answer > number) res = "Ваше число больше загаданного";
                else if (answer < number) res = "Ваше число меньше загаданного";

                result.setText(res);
            }
        };

        setAnswer.setOnClickListener(answerSet);
        checkAnswer.setOnClickListener(answerInput);
    }
}